
import {React} from 'jimu-core';

export const SearchWidgetContext = React.createContext({});