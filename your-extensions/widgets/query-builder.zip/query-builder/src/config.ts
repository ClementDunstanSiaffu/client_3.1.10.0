import { ImmutableObject } from 'seamless-immutable'

export interface Config {
  'idWidgetTable': string
}

export type IMConfig = ImmutableObject<Config>
