
export default({
    _widgetLabel:"Carica i livelli del file",
    noFeatures:"Non ci sono caratteristiche all'interno del file",
    noKMLFile:"Nessun file kml trovato all'interno del file kmz",
    noFilesFound:"Non ci sono file all'interno del file kmz"
})