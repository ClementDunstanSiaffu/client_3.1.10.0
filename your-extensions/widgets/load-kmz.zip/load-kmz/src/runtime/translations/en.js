
System.register([], function (_export) {return {execute: function () {_export({
    _widgetLabel:"Load file layers",
    "noFeatures":"There is no features inside the file",
    "noKMLFile":"No kml file found inside the kmz file",
    "noFilesFound":"There are no files inside the kmz file"
})}}});
