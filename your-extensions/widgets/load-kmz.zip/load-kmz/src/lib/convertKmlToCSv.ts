

const convertKMlToCSV = (domVal)=>{
    if (domVal){
        const placemarks = domVal.getElementByTagName("PlaceMark");
        
    }
}