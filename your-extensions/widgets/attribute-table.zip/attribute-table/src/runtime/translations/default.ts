/**

 */
export default {
    _widgetLabel: 'Tabella degli attributi',
    noTableOpened:"Nessuna tabella aperta o nessun risultato trovato",
    download:"Scaricare",
    exportKMZ:"Esporta Selezione in KMZ",
    exportEcgiToCsv:"Esporta Colonna eCGI in CSV",
    exportCgiToCsv:"Esporta Colonna CGI in CSV",
    exportCsvSelectedTable:"Esporta CSV tabella selezionata",
    exportAllTable:"Esporta CSV tutte le tabelle",
    highlightColor:"Colore evidenziazione",
    randomColor:"Colore casuale",
    chooseColor:"Scegli il colore",
    clearHightlight:"Cancella le evidenziazioni",
    clearFilter:"Cancella filtro",
    filterByExtention:"Filtra per estenzione mappa",
    filter:"Filtra",
    closeAllTab:"Chiudi tutti i tab"
}
