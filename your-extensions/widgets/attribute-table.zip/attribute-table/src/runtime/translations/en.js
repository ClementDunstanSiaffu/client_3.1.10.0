
System.register([], function (_export) {return {execute: function () {_export({
    _widgetLabel:"Attribute table",
    "noTableOpened":"No table opened or no results found",
    "download":"Download",
    "exportKMZ":"Export Selection to KMZ",
    "exportEcgiToCsv":"Export eCGI Column to CSV",
    "exportCgiToCsv":"Export CGI Column to CSV",
    "exportCsvSelectedTable":"Export CSV selected table",
    "exportAllTable":"Export CSV all tables",
    "highlightColor":"Highlight Color",
    "randomColor":"Random color",
    "chooseColor":"Choose the color",
    "clearHightlight":"Clear highlights",
    "clearFilter":"Clear filter",
    "filterByExtention":"Filter by map extension",
    "filter":"Filter",
    "closeAllTab":"Close all tabs"
})}}});

